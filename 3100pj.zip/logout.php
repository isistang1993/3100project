<?php
require_once('../Connections/conn.php');
session_start();
session_unset();
//header("HTTP/1.1 301 Moved Permanently");
//header("Location: index.php");
?>
back to <a href="index.php">online store</a>
