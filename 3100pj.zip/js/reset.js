$(window).load(function() {
	$("#btn_password").click(function(){
		console.log("AS");
	});
});